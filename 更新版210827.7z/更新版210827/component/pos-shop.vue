<template>
	<div>
		<div   style="background-color:#BFFFFF;height:450px;width:100%; ">
			01-01雞肉飯
		</div>
		<div   style="background-color:#EEEEEE;"><a class="nav-link" @click="change('home')">關閉</a></div>
	</div>
</template>


<script>
module.exports = {
    data() {
        return {
            
        }
    },
	 methods: {
		change: function(tab){
			
		  //alert(tab);		
		  //this.$root.view=tab;
		  
		  this.$emit('update', tab);  //Component內層透過this.$emit觸發外層changeView事件
		  
		}
		}, 	
	
}
</script>